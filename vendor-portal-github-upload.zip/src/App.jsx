import React, { useState } from "react";
import "./App.css";

const mockPOs = [
  {
    poNumber: "PO12345",
    date: "2025-05-15",
    documents: {
      imeiList: "Missing",
      shippingLabel: "Submitted",
      commercialInvoice: "Missing",
      invoice: "Under Review",
      creditNote: "Missing",
    },
  },
  {
    poNumber: "PO67890",
    date: "2025-05-10",
    documents: {
      imeiList: "Submitted",
      shippingLabel: "Submitted",
      commercialInvoice: "Submitted",
      invoice: "Submitted",
      creditNote: "Missing",
    },
  },
];

export default function VendorPortal() {
  const [tab, setTab] = useState("home");
  const [search, setSearch] = useState("");
  const filteredPOs = mockPOs.filter(po => po.poNumber.includes(search));

  return (
    <div className="container">
      <div className="tabs">
        <button onClick={() => setTab("home")}>Home</button>
        <button onClick={() => setTab("dashboard")}>Pending POs Dashboard</button>
        <button onClick={() => setTab("upload")}>Upload Document</button>
      </div>

      {tab === "home" && (
        <div className="tab-content">
          <h1>Welcome</h1>
          <p>You are logged in as a Vendor of Swappie Oy.</p>
          <p>Supplier: XYZ Electronics Ltd.</p>
          <p>Contact: supplier@xyz.com</p>
        </div>
      )}

      {tab === "dashboard" && (
        <div className="tab-content">
          <input
            placeholder="Search by PO number or date"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          {filteredPOs.map(po => (
            <div key={po.poNumber} className="po-card">
              <h2>PO: {po.poNumber}</h2>
              <p>Date: {po.date}</p>
              <div className="docs">
                {Object.entries(po.documents).map(([docType, status]) => (
                  <div key={docType}>
                    <span>{docType.replace(/([A-Z])/g, " $1")}: </span>
                    <span>{status}</span>
                    {status === "Missing" && <button>Upload</button>}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "upload" && (
        <div className="tab-content">
          <h2>Upload Documents</h2>
          <input placeholder="Search PO by number" />
          {["IMEI List", "Shipping Label", "Commercial Invoice", "Invoice", "Credit Note"].map(doc => (
            <div key={doc}>
              <span>{doc}</span>
              <input type="file" />
            </div>
          ))}
          <button>Submit Documents</button>
        </div>
      )}
    </div>
  );
}
